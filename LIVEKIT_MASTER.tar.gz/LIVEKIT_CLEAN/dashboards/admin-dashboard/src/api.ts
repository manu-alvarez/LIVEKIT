import axios from 'axios';

// In production this should point to the public domain or VITE_API_URL
// For now we use the relative path if served from the same Nginx,
// or the direct domain for local development.
const baseURL = import.meta.env.VITE_API_URL || 'https://livekit.alvarezconsult.com/api';

export const api = axios.create({
    baseURL,
    headers: {
        'Content-Type': 'application/json',
    },
});

export const getStats = (date?: string) => api.get('/stats', { params: { date } });
export const getReservations = (date?: string, status?: string) => api.get('/reservations', { params: { date, status } });
export const createReservation = (data: any) => api.post('/reservations', data);
export const cancelReservation = (id: number) => api.delete(`/reservations/${id}`);

export const getTables = (active_only = false) => api.get('/tables', { params: { active_only } });
export const createTable = (data: any) => api.post('/tables', data);
export const updateTable = (id: number, data: any) => api.put(`/tables/${id}`, data);
export const deleteTable = (id: number) => api.delete(`/tables/${id}`);

export const getRestaurantInfo = () => api.get('/restaurant');
export const updateRestaurantInfo = (data: any) => api.put('/restaurant', data);

export const getCalls = (limit = 50) => api.get('/calls', { params: { limit } });
